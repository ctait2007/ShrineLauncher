package com.shrine.launcher.data.model

import android.graphics.drawable.Drawable

// ── App Info ─────────────────────────────────────────────────────────────────

data class AppInfo(
    val packageName: String,
    val label: String,
    val icon: Drawable?,
    val isSystemApp: Boolean = false
)

// ── Row types ─────────────────────────────────────────────────────────────────

enum class RowType {
    ALL_APPS,
    FAVORITES,
    CUSTOM,
    CONTINUE_WATCHING,
    RECENTLY_OPENED,
    SUGGESTIONS
}

data class LauncherRow(
    val id: String,
    val title: String,
    val type: RowType,
    val apps: MutableList<String> = mutableListOf(), // packageNames for CUSTOM/FAVORITES
    val isVisible: Boolean = true,
    val isPinned: Boolean = false       // pinned rows appear above the main list
)

// ── Continue Watching entry ───────────────────────────────────────────────────

data class ContinueWatchingEntry(
    val id: String,
    val title: String,
    val subtitle: String,           // e.g. "S2 E4 • Netflix"
    val packageName: String,        // app that owns this entry
    val deepLinkUri: String?,       // URI to resume playback
    val artworkUri: String?,        // thumbnail / backdrop
    val progressMs: Long = 0,       // playback position
    val durationMs: Long = 0        // total duration (0 = unknown)
) {
    val progressPercent: Int
        get() = if (durationMs > 0) ((progressMs * 100) / durationMs).toInt() else 0
}

// ── Widget descriptor ─────────────────────────────────────────────────────────

enum class WidgetType {
    CONTINUE_WATCHING,
    CLOCK,
    WEATHER,
    QUICK_SETTINGS
}

data class PinnedWidget(
    val id: String,
    val type: WidgetType,
    val title: String,
    val position: Int = 0           // order among pinned widgets
)

// ── Theme ─────────────────────────────────────────────────────────────────────

data class LauncherTheme(
    val id: String,
    val name: String,
    val backgroundColorHex: String  = "#0D0D0D",
    val accentColorHex: String      = "#E040FB",
    val cardColorHex: String        = "#1E1E1E",
    val textPrimaryHex: String      = "#FFFFFF",
    val textSecondaryHex: String    = "#B0B0B0",
    val useDynamicColor: Boolean    = false,
    val backgroundImageUri: String? = null,
    val backgroundBlur: Int         = 0,         // 0-25
    val backgroundDim: Int          = 60         // 0-100
)

// ── Preferences snapshot (serialised to JSON) ─────────────────────────────────

data class LauncherPrefs(
    val rows: List<LauncherRow>             = defaultRows(),
    val pinnedWidgets: List<PinnedWidget>   = emptyList(),
    val theme: LauncherTheme                = LauncherTheme("default", "Dark"),
    val clockEnabled: Boolean               = true,
    val clockFormat24h: Boolean             = false,
    val focusScaleEnabled: Boolean          = true,
    val focusScaleFactor: Float             = 1.12f,
    val rowLabelStyle: String               = "ABOVE",  // ABOVE | INLINE | HIDDEN
    val iconSize: Int                       = 96,       // dp
    val cardStyle: String                   = "ROUNDED",// ROUNDED | SQUARE | CIRCLE
    val animationsEnabled: Boolean          = true
)

private fun defaultRows(): List<LauncherRow> = listOf(
    LauncherRow("row_favorites",  "Favorites",       RowType.FAVORITES),
    LauncherRow("row_all_apps",   "All Apps",        RowType.ALL_APPS),
    LauncherRow("row_recent",     "Recently Opened", RowType.RECENTLY_OPENED)
)
