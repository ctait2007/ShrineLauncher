package com.shrine.launcher.ui.home

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.shrine.launcher.R
import com.shrine.launcher.data.model.AppInfo

class AppContextMenuDialog(
    context: Context,
    private val app: AppInfo,
    private val isFavourite: Boolean,
    private val onFavouriteToggle: () -> Unit,
    private val onLaunch: () -> Unit
) : Dialog(context) {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.dialog_app_context_menu)
        window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setGravity(Gravity.CENTER)
            setLayout(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT
            )
        }

        findViewById<ImageView>(R.id.ivAppIconMenu).setImageDrawable(app.icon)
        findViewById<TextView>(R.id.tvAppNameMenu).text = app.label

        val btnFav = findViewById<Button>(R.id.btnToggleFavourite)
        btnFav.text = if (isFavourite) "Remove from Favourites" else "Add to Favourites"
        btnFav.setOnClickListener {
            onFavouriteToggle()
            dismiss()
        }

        findViewById<Button>(R.id.btnOpen).setOnClickListener {
            onLaunch()
            dismiss()
        }

        findViewById<Button>(R.id.btnCancel).setOnClickListener { dismiss() }
    }
}
