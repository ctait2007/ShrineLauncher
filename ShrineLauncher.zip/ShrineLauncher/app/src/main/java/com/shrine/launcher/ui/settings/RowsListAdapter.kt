package com.shrine.launcher.ui.settings

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.shrine.launcher.R
import com.shrine.launcher.data.model.LauncherRow

class RowsListAdapter(
    private val onEdit: (LauncherRow) -> Unit,
    private val onDelete: (LauncherRow) -> Unit,
    private val onVisibilityToggle: (LauncherRow) -> Unit
) : RecyclerView.Adapter<RowsListAdapter.VH>() {

    var currentRows: List<LauncherRow> = emptyList()
        private set

    fun setRows(rows: List<LauncherRow>) {
        currentRows = rows
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_settings_row, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) =
        holder.bind(currentRows[position])

    override fun getItemCount() = currentRows.size

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        private val tvName:   TextView    = view.findViewById(R.id.tvSettingsRowName)
        private val tvType:   TextView    = view.findViewById(R.id.tvSettingsRowType)
        private val btnEdit:  ImageButton = view.findViewById(R.id.btnEditRow)
        private val btnDel:   ImageButton = view.findViewById(R.id.btnDeleteRow)
        private val btnVis:   ImageButton = view.findViewById(R.id.btnToggleVisibility)

        fun bind(row: LauncherRow) {
            tvName.text = row.title
            tvType.text = row.type.name.replace('_', ' ')
            btnVis.setImageResource(
                if (row.isVisible) R.drawable.ic_visibility_on
                else R.drawable.ic_visibility_off
            )
            btnEdit.setOnClickListener  { onEdit(row) }
            btnDel.setOnClickListener   { onDelete(row) }
            btnVis.setOnClickListener   { onVisibilityToggle(row) }
        }
    }
}
