package com.shrine.launcher.ui.home

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.shrine.launcher.R
import com.shrine.launcher.data.model.AppInfo
import com.shrine.launcher.data.model.LauncherRow

data class RowItem(
    val row: LauncherRow,
    val apps: List<AppInfo>
)

class RowsAdapter(
    private val onAppClick: (AppInfo) -> Unit,
    private val onAppLongClick: (AppInfo) -> Unit,
    private val onRowFocused: (String) -> Unit
) : ListAdapter<RowItem, RowsAdapter.RowViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowViewHolder {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_row, parent, false)
        return RowViewHolder(v)
    }

    override fun onBindViewHolder(holder: RowViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class RowViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val tvLabel: TextView        = view.findViewById(R.id.tvRowLabel)
        private val rvApps: RecyclerView     = view.findViewById(R.id.rvApps)

        fun bind(item: RowItem) {
            tvLabel.text = item.row.title
            tvLabel.visibility = if (item.row.title.isBlank()) View.GONE else View.VISIBLE

            val appsAdapter = AppsAdapter(
                onAppClick     = onAppClick,
                onAppLongClick = onAppLongClick,
                onFocused      = { onRowFocused(item.row.title) }
            )
            rvApps.apply {
                layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
                adapter = appsAdapter
                setHasFixedSize(true)
            }
            appsAdapter.submitList(item.apps)
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<RowItem>() {
            override fun areItemsTheSame(a: RowItem, b: RowItem) = a.row.id == b.row.id
            override fun areContentsTheSame(a: RowItem, b: RowItem) =
                a.row == b.row && a.apps == b.apps
        }
    }
}
