package com.shrine.launcher.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.shrine.launcher.data.model.*
import com.shrine.launcher.data.repository.AppRepository
import com.shrine.launcher.data.repository.PreferencesRepository
import kotlinx.coroutines.launch

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val appRepo  = AppRepository.getInstance(application)
    private val prefRepo = PreferencesRepository.getInstance(application)

    private val _allApps = MutableLiveData<List<AppInfo>>()
    val allApps: LiveData<List<AppInfo>> = _allApps

    private val _recentApps = MutableLiveData<List<AppInfo>>()
    val recentApps: LiveData<List<AppInfo>> = _recentApps

    private val _rows = MutableLiveData<List<LauncherRow>>()
    val rows: LiveData<List<LauncherRow>> = _rows

    private val _widgets = MutableLiveData<List<PinnedWidget>>()
    val widgets: LiveData<List<PinnedWidget>> = _widgets

    private val _continueWatching = MutableLiveData<List<ContinueWatchingEntry>>()
    val continueWatching: LiveData<List<ContinueWatchingEntry>> = _continueWatching

    private val _theme = MutableLiveData<LauncherTheme>()
    val theme: LiveData<LauncherTheme> = _theme

    private val _prefs = MutableLiveData<LauncherPrefs>()
    val prefs: LiveData<LauncherPrefs> = _prefs

    private val _favourites = MutableLiveData<List<String>>()
    val favourites: LiveData<List<String>> = _favourites

    init {
        loadAll()
    }

    fun loadAll() {
        viewModelScope.launch {
            _allApps.value    = appRepo.getAllApps()
            _recentApps.value = appRepo.getRecentlyUsed()
        }
        val p = prefRepo.loadPrefs()
        _prefs.value           = p
        _rows.value            = p.rows.filter { it.isVisible }
        _widgets.value         = p.pinnedWidgets.sortedBy { it.position }
        _theme.value           = p.theme
        _continueWatching.value = prefRepo.loadContinueWatching()
        _favourites.value      = prefRepo.loadFavourites()
    }

    fun launchApp(packageName: String) = appRepo.launchApp(packageName)

    fun toggleFavourite(packageName: String) {
        prefRepo.toggleFavourite(packageName)
        _favourites.value = prefRepo.loadFavourites()
    }

    fun removeContinueWatching(id: String) {
        prefRepo.removeContinueWatchingEntry(id)
        _continueWatching.value = prefRepo.loadContinueWatching()
    }

    fun getAppsForRow(row: LauncherRow): List<AppInfo> {
        return when (row.type) {
            RowType.ALL_APPS         -> _allApps.value ?: emptyList()
            RowType.RECENTLY_OPENED  -> _recentApps.value ?: emptyList()
            RowType.FAVORITES        -> {
                val favs = _favourites.value ?: emptyList()
                (_allApps.value ?: emptyList()).filter { it.packageName in favs }
                    .sortedBy { favs.indexOf(it.packageName) }
            }
            RowType.CUSTOM           -> {
                val all = (_allApps.value ?: emptyList()).associateBy { it.packageName }
                row.apps.mapNotNull { all[it] }
            }
            RowType.SUGGESTIONS      -> (_allApps.value ?: emptyList()).take(12)
            RowType.CONTINUE_WATCHING -> emptyList() // handled separately via widget
        }
    }
}
