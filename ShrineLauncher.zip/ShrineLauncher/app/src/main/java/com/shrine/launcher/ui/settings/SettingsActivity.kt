package com.shrine.launcher.ui.settings

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.shrine.launcher.R
import com.shrine.launcher.data.model.*
import com.shrine.launcher.data.repository.PreferencesRepository
import com.shrine.launcher.databinding.ActivitySettingsBinding
import java.util.Collections
import java.util.UUID

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var repo: PreferencesRepository
    private lateinit var rowsListAdapter: RowsListAdapter
    private lateinit var widgetsListAdapter: WidgetsListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repo = PreferencesRepository.getInstance(this)

        setupRowsManager()
        setupWidgetsManager()
        setupThemeSettings()
        setupAppearanceSettings()
        setupClockSettings()

        binding.btnBack.setOnClickListener { finish() }
    }

    // ── Rows ───────────────────────────────────────────────────────────────────

    private fun setupRowsManager() {
        rowsListAdapter = RowsListAdapter(
            onEdit   = { row -> openRowEditor(row) },
            onDelete = { row ->
                repo.removeRow(row.id)
                reloadRows()
            },
            onVisibilityToggle = { row ->
                repo.updateRow(row.copy(isVisible = !row.isVisible))
                reloadRows()
            }
        )
        binding.rvRows.apply {
            layoutManager = LinearLayoutManager(this@SettingsActivity)
            adapter = rowsListAdapter
        }

        // Drag-to-reorder
        val touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0
        ) {
            override fun onMove(rv: RecyclerView, vh: RecyclerView.ViewHolder,
                                target: RecyclerView.ViewHolder): Boolean {
                val from = vh.adapterPosition
                val to   = target.adapterPosition
                val rows = rowsListAdapter.currentRows.toMutableList()
                Collections.swap(rows, from, to)
                repo.saveRows(rows)
                rowsListAdapter.setRows(rows)
                return true
            }
            override fun onSwiped(vh: RecyclerView.ViewHolder, dir: Int) {}
        })
        touchHelper.attachToRecyclerView(binding.rvRows)

        binding.btnAddRow.setOnClickListener { showAddRowDialog() }
        reloadRows()
    }

    private fun reloadRows() {
        rowsListAdapter.setRows(repo.loadRows())
    }

    private fun openRowEditor(row: LauncherRow) {
        val intent = Intent(this, RowEditorActivity::class.java)
        intent.putExtra(RowEditorActivity.EXTRA_ROW_ID, row.id)
        startActivity(intent)
    }

    private fun showAddRowDialog() {
        val types = RowType.values()
        val labels = types.map { it.name.replace('_', ' ') }.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Add Row")
            .setItems(labels) { _, which ->
                val type = types[which]
                val newRow = LauncherRow(
                    id    = UUID.randomUUID().toString(),
                    title = labels[which],
                    type  = type
                )
                repo.addRow(newRow)
                reloadRows()
            }
            .show()
    }

    // ── Widgets ────────────────────────────────────────────────────────────────

    private fun setupWidgetsManager() {
        widgetsListAdapter = WidgetsListAdapter(
            onRemove = { widget ->
                repo.removeWidget(widget.id)
                reloadWidgets()
            }
        )
        binding.rvWidgets.apply {
            layoutManager = LinearLayoutManager(this@SettingsActivity)
            adapter = widgetsListAdapter
        }

        binding.btnAddWidget.setOnClickListener { showAddWidgetDialog() }
        reloadWidgets()
    }

    private fun reloadWidgets() {
        widgetsListAdapter.setWidgets(repo.loadWidgets())
    }

    private fun showAddWidgetDialog() {
        val types  = WidgetType.values()
        val labels = types.map { it.name.replace('_', ' ') }.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Pin Widget")
            .setItems(labels) { _, which ->
                repo.addWidget(types[which], labels[which])
                reloadWidgets()
            }
            .show()
    }

    // ── Theme ──────────────────────────────────────────────────────────────────

    private fun setupThemeSettings() {
        val prefs = repo.loadPrefs()
        val theme = prefs.theme

        binding.etAccentColor.setText(theme.accentColorHex)
        binding.etBgColor.setText(theme.backgroundColorHex)
        binding.switchDynamicColor.isChecked = theme.useDynamicColor
        binding.sbBackgroundDim.progress     = theme.backgroundDim
        binding.sbBackgroundBlur.progress    = theme.backgroundBlur

        binding.btnSaveTheme.setOnClickListener {
            val updated = theme.copy(
                accentColorHex      = binding.etAccentColor.text.toString().ifBlank { theme.accentColorHex },
                backgroundColorHex  = binding.etBgColor.text.toString().ifBlank { theme.backgroundColorHex },
                useDynamicColor     = binding.switchDynamicColor.isChecked,
                backgroundDim       = binding.sbBackgroundDim.progress,
                backgroundBlur      = binding.sbBackgroundBlur.progress
            )
            repo.saveTheme(updated)
            Toast.makeText(this, "Theme saved", Toast.LENGTH_SHORT).show()
        }
    }

    // ── Appearance ─────────────────────────────────────────────────────────────

    private fun setupAppearanceSettings() {
        val prefs = repo.loadPrefs()

        binding.sbIconSize.progress         = prefs.iconSize - 48   // range 48-144
        binding.switchFocusScale.isChecked  = prefs.focusScaleEnabled
        binding.switchAnimations.isChecked  = prefs.animationsEnabled

        val cardStyles = arrayOf("ROUNDED", "SQUARE", "CIRCLE")
        binding.spinnerCardStyle.adapter    = ArrayAdapter(this,
            android.R.layout.simple_spinner_item, cardStyles)
        binding.spinnerCardStyle.setSelection(cardStyles.indexOf(prefs.cardStyle).coerceAtLeast(0))

        val rowLabelStyles = arrayOf("ABOVE", "INLINE", "HIDDEN")
        binding.spinnerRowLabelStyle.adapter = ArrayAdapter(this,
            android.R.layout.simple_spinner_item, rowLabelStyles)
        binding.spinnerRowLabelStyle.setSelection(
            rowLabelStyles.indexOf(prefs.rowLabelStyle).coerceAtLeast(0))

        binding.btnSaveAppearance.setOnClickListener {
            val updated = prefs.copy(
                iconSize          = binding.sbIconSize.progress + 48,
                focusScaleEnabled = binding.switchFocusScale.isChecked,
                animationsEnabled = binding.switchAnimations.isChecked,
                cardStyle         = cardStyles[binding.spinnerCardStyle.selectedItemPosition],
                rowLabelStyle     = rowLabelStyles[binding.spinnerRowLabelStyle.selectedItemPosition]
            )
            repo.savePrefs(updated)
            Toast.makeText(this, "Appearance saved", Toast.LENGTH_SHORT).show()
        }
    }

    // ── Clock ──────────────────────────────────────────────────────────────────

    private fun setupClockSettings() {
        val prefs = repo.loadPrefs()
        binding.switchClock.isChecked   = prefs.clockEnabled
        binding.switch24h.isChecked     = prefs.clockFormat24h

        binding.btnSaveClock.setOnClickListener {
            repo.savePrefs(prefs.copy(
                clockEnabled   = binding.switchClock.isChecked,
                clockFormat24h = binding.switch24h.isChecked
            ))
            Toast.makeText(this, "Clock settings saved", Toast.LENGTH_SHORT).show()
        }
    }
}
