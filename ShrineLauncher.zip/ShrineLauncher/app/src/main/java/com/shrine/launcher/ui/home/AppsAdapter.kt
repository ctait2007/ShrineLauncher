package com.shrine.launcher.ui.home

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.shrine.launcher.R
import com.shrine.launcher.data.model.AppInfo

class AppsAdapter(
    private val onAppClick: (AppInfo) -> Unit,
    private val onAppLongClick: (AppInfo) -> Unit,
    private val onFocused: () -> Unit
) : ListAdapter<AppInfo, AppsAdapter.AppViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_app_card, parent, false)
        return AppViewHolder(v)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class AppViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val ivIcon: ImageView  = view.findViewById(R.id.ivAppIcon)
        private val tvName: TextView   = view.findViewById(R.id.tvAppName)
        private val cardRoot: View     = view.findViewById(R.id.cardRoot)

        fun bind(app: AppInfo) {
            ivIcon.setImageDrawable(app.icon)
            tvName.text = app.label

            cardRoot.setOnClickListener { onAppClick(app) }
            cardRoot.setOnLongClickListener { onAppLongClick(app); true }

            cardRoot.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
                if (hasFocus) onFocused()
                val scale = if (hasFocus) 1.14f else 1f
                v.animate()
                    .scaleX(scale).scaleY(scale)
                    .translationZ(if (hasFocus) 8f else 0f)
                    .setDuration(130)
                    .start()
                tvName.visibility = if (hasFocus) View.VISIBLE else View.GONE
            }
            cardRoot.isFocusable = true
            cardRoot.isFocusableInTouchMode = false
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<AppInfo>() {
            override fun areItemsTheSame(a: AppInfo, b: AppInfo) =
                a.packageName == b.packageName
            override fun areContentsTheSame(a: AppInfo, b: AppInfo) =
                a.packageName == b.packageName && a.label == b.label
        }
    }
}
