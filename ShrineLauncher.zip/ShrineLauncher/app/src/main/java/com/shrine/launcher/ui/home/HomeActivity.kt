package com.shrine.launcher.ui.home

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.shrine.launcher.R
import com.shrine.launcher.data.model.*
import com.shrine.launcher.databinding.ActivityHomeBinding
import com.shrine.launcher.ui.settings.SettingsActivity
import com.shrine.launcher.ui.widgets.ContinueWatchingWidgetView
import com.shrine.launcher.util.ThemeUtil
import java.text.SimpleDateFormat
import java.util.*

class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding
    private val vm: HomeViewModel by viewModels()

    private lateinit var rowsAdapter: RowsAdapter
    private var clockTimer: Timer? = null

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            vm.loadAll()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRows()
        setupClock()
        setupObservers()
        setupButtons()
        registerPackageReceiver()
    }

    // ── Rows RecyclerView ──────────────────────────────────────────────────────

    private fun setupRows() {
        rowsAdapter = RowsAdapter(
            onAppClick    = { app -> vm.launchApp(app.packageName) },
            onAppLongClick = { app -> showAppContextMenu(app) },
            onRowFocused  = { rowTitle -> binding.tvFocusedRowLabel.text = rowTitle }
        )
        binding.rvRows.apply {
            layoutManager = LinearLayoutManager(this@HomeActivity)
            adapter = rowsAdapter
            setHasFixedSize(false)
        }
    }

    // ── Observers ──────────────────────────────────────────────────────────────

    private fun setupObservers() {
        vm.rows.observe(this) { rows -> rebuildRows(rows) }
        vm.allApps.observe(this) { rebuildRows(vm.rows.value ?: emptyList()) }
        vm.recentApps.observe(this) { rebuildRows(vm.rows.value ?: emptyList()) }
        vm.favourites.observe(this) { rebuildRows(vm.rows.value ?: emptyList()) }

        vm.widgets.observe(this) { widgets -> rebuildWidgets(widgets) }
        vm.continueWatching.observe(this) { entries ->
            updateContinueWatchingWidget(entries)
        }

        vm.theme.observe(this) { theme -> applyTheme(theme) }
        vm.prefs.observe(this) { prefs -> applyClock(prefs) }
    }

    private fun rebuildRows(rows: List<LauncherRow>) {
        val rowData = rows.map { row ->
            RowItem(row = row, apps = vm.getAppsForRow(row))
        }
        rowsAdapter.submitList(rowData)
    }

    // ── Widgets area (pinned above rows) ───────────────────────────────────────

    private fun rebuildWidgets(widgets: List<PinnedWidget>) {
        binding.widgetContainer.removeAllViews()
        widgets.sortedBy { it.position }.forEach { widget ->
            when (widget.type) {
                WidgetType.CONTINUE_WATCHING -> {
                    val cwView = ContinueWatchingWidgetView(this)
                    cwView.tag = "widget_cw"
                    cwView.setEntries(vm.continueWatching.value ?: emptyList())
                    cwView.setOnEntryClickListener { entry ->
                        entry.deepLinkUri?.let { uri ->
                            try {
                                startActivity(Intent(Intent.ACTION_VIEW,
                                    android.net.Uri.parse(uri))
                                    .apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
                            } catch (e: Exception) {
                                vm.launchApp(entry.packageName)
                            }
                        } ?: vm.launchApp(entry.packageName)
                    }
                    cwView.setOnEntryRemoveListener { entry ->
                        vm.removeContinueWatching(entry.id)
                    }
                    binding.widgetContainer.addView(cwView)
                }
                WidgetType.CLOCK -> { /* handled by top bar clock */ }
                else -> { /* future widget types */ }
            }
        }
        binding.widgetContainer.visibility =
            if (widgets.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun updateContinueWatchingWidget(entries: List<ContinueWatchingEntry>) {
        val cwView = binding.widgetContainer.findViewWithTag<ContinueWatchingWidgetView>("widget_cw")
        cwView?.setEntries(entries)
    }

    // ── Clock ──────────────────────────────────────────────────────────────────

    private fun setupClock() {
        clockTimer = Timer()
        clockTimer?.scheduleAtFixedRate(object : TimerTask() {
            override fun run() {
                runOnUiThread { updateClock() }
            }
        }, 0, 30_000)
    }

    private fun applyClock(prefs: LauncherPrefs) {
        binding.tvClock.visibility = if (prefs.clockEnabled) View.VISIBLE else View.GONE
        updateClock()
    }

    private fun updateClock() {
        val prefs  = vm.prefs.value ?: return
        val fmt    = if (prefs.clockFormat24h) "HH:mm" else "h:mm a"
        val dateFmt = SimpleDateFormat("EEE, MMM d", Locale.getDefault())
        val timeFmt = SimpleDateFormat(fmt, Locale.getDefault())
        val now    = Date()
        binding.tvClock.text    = timeFmt.format(now)
        binding.tvDate.text     = dateFmt.format(now)
    }

    // ── Theme ──────────────────────────────────────────────────────────────────

    private fun applyTheme(theme: LauncherTheme) {
        ThemeUtil.applyToActivity(this, binding.root, theme)
    }

    // ── Buttons ────────────────────────────────────────────────────────────────

    private fun setupButtons() {
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.btnSettings.setOnFocusChangeListener { v, hasFocus ->
            v.animate().scaleX(if (hasFocus) 1.15f else 1f)
                .scaleY(if (hasFocus) 1.15f else 1f).setDuration(120).start()
        }
    }

    // ── App context menu (long press) ──────────────────────────────────────────

    private fun showAppContextMenu(app: AppInfo) {
        val dialog = AppContextMenuDialog(this, app,
            isFavourite = vm.favourites.value?.contains(app.packageName) == true,
            onFavouriteToggle = { vm.toggleFavourite(app.packageName) },
            onLaunch = { vm.launchApp(app.packageName) }
        )
        dialog.show()
    }

    // ── Package install/uninstall receiver ─────────────────────────────────────

    private fun registerPackageReceiver() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        registerReceiver(packageReceiver, filter)
    }

    // ── Key events (back button should NOT exit the launcher) ─────────────────

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            // On the home screen, back does nothing
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onResume() {
        super.onResume()
        vm.loadAll()
    }

    override fun onDestroy() {
        super.onDestroy()
        clockTimer?.cancel()
        try { unregisterReceiver(packageReceiver) } catch (e: Exception) { }
    }
}
